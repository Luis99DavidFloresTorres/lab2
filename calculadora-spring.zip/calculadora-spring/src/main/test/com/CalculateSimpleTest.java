package com;

import com.example.model.OperationModel;
import com.example.service.CalculateSimple;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculateSimpleTest {
    private CalculateSimple calculateSimple = new CalculateSimple();
    @Test
    void add() {
        OperationModel op = new OperationModel(3,7);
        Assert.assertEquals(10,calculateSimple.add(op));
    }

    @Test
    void subtract() {
        OperationModel op = new OperationModel(13,5);
        Assert.assertEquals(8,calculateSimple.subtract(op));
    }

    @Test
    void multiply() {
        OperationModel op = new OperationModel(1,5);
        Assert.assertEquals(5,calculateSimple.multiply(op));
    }

    @Test
    void divide() {
        OperationModel op = new OperationModel(2,2);
        Assert.assertEquals(1,(int)calculateSimple.divide(op));
    }

    @Test
    void factorial() {
        OperationModel op = new OperationModel(3);
        Assert.assertEquals(6,calculateSimple.factorial(op));
    }

    @Test
    void fibonacci() {
        OperationModel op = new OperationModel(9);
        Assert.assertEquals(34,calculateSimple.fibonacci(op));
    }

    @Test
    void sqrt() {
        OperationModel op = new OperationModel(4);

        Assert.assertEquals(2,(int)calculateSimple.sqrt(op));
    }

    @Test
    void power() {
        OperationModel op = new OperationModel(3);
        Assert.assertEquals(9,calculateSimple.power(op));
    }

    @Test
    void clearSimple() {
        OperationModel op = new OperationModel(7,3);

        Assert.assertEquals(op,calculateSimple.clearSimple(op));
    }

    @Test
    void clearAdvanced() {
        OperationModel op = new OperationModel(7);

        Assert.assertEquals(op,calculateSimple.clearAdvanced(op));
    }
}
